from .models import Announcement, Category
from .forms import AnnouncementForm
from django.shortcuts import render, get_object_or_404


def announcement_detail(request, announcement_id):
    announcement = get_object_or_404(Announcement, id=announcement_id)
    return render(request, 'announcement_detail.html', {'announcement': announcement})

def index(request):
    announcements = Announcement.objects.all()
    return render(request, 'index.html', {'announcements': announcements})

def create_announcement(request):
    if request.method == "POST":
        form = AnnouncementForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = AnnouncementForm()
    return render(request, 'create_announcement.html', {'form': form})
