from django.urls import path
from .views import announcement_detail, announcement_list

urlpatterns = [
    path('', announcement_list, name='announcement_list'), 
    path('<int:pk>/', announcement_detail, name='announcement_detail'), 
]
